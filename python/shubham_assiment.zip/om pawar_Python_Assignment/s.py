# Initialize tracking variables before the loop starts
highest = 0
lowest = 0

# Loop exactly 6 times
for i in range(1, 7):
    val = int(input("Enter value " + str(i) + ": "))
    
    # On the very first iteration, set the baseline values
    if i == 1:
        highest = val
        lowest = val
    else:
        # For all remaining iterations, compare against the running records
        if val > highest:
            highest = val
        if val < lowest:
            lowest = val

# Output the results
print("Highest value:", highest)
print("Lowest value:", lowest)
