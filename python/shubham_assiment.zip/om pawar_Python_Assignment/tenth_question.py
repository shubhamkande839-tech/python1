total_annual_s=0

high_monthly_s=0
lowest_monthly_s=0
no_m_s_a=0

for i in range(1,13):
    month=int(input("enter the sale in the month no "+ str(i)+ ":"))
    if month>0:
        total_annual_s=total_annual_s+month
        
        avg_monthly_s=total_annual_s/12
        
        if month>100000:
            no_m_s_a=no_m_s_a+1
            p_h_m_s=no_m_s_a/12*100
            
    if i == 1:
                high_monthly_s = month
                lowest_monthly_s = month
    else:
    
         if month > high_monthly_s:
            high_monthly_s = month
         if month < lowest_monthly_s:
            lowest_monthly_s = month



print(total_annual_s,"is total annual sale")
print(avg_monthly_s,"is average monthly sale")
print(no_m_s_a,"is sale of month above 100000")
print(high_monthly_s,"is high sale")
print(lowest_monthly_s,"is low sale")
print(p_h_m_s,"percentage of high month sales")