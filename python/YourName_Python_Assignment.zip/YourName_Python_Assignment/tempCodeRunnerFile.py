#let total working days 7 
print("TOTAL WORKING DAYS ARE 7 DAYS")
print("enter your attendace in 1 for present and 0 for absent ")
attendance=input("attendance=")

t_d=7
p_d=0
a_d=0

for i in attendance:
    if i==1:
        p_d=p_d+1
        print("Total present days are :",p_d)
        
    elif i==0:
        a_d=a_d+1
        print("Total absent days are :",a_d)
        
            
    
